﻿var scriptName = "Title"
var scriptVersion = 1.1
var scriptAuthor = "None"

var Title = new Title()
var client

function Title() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
	this.getName = function() {
        return "IQBOOST114514++++++++++++++"
    }

    this.getDescription = function() {
        return "IQBOOST114514++++++++++++++"
    }

    this.getCategory = function() {
        return "Fun"
    }
    this.onUpdate = function() {
		 HM += 1
		 if (HM ==20){
		   S = S + 1
		   HM = 0
		   
		  }
		 if (S ==60){
		   M = M +1
		   S = 0
		  }
		  if (M==60){
		   H = H+1
		   M = 0
		  }
		Display.setTitle(' CatSense /【猫-染】客户端 || 官方群 553849936 by 小猫很可爱 || 永远少年。永远赤诚。永远年轻，永远渴望踏上新的征程。|| 您已游玩：' +  H  +'h  '  +M +'m  '+S+'s' )
	}
}

var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Title)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}