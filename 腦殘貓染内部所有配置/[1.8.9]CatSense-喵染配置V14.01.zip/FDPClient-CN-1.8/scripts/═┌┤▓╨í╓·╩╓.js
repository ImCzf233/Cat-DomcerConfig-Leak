﻿var scriptName = "FuckerHelper";
var scriptAuthor = "猫猫";
var scriptVersion = 1.0;

var Fucker = moduleManager.getModule("Fucker");
var Killaura = moduleManager.getModule("Killaura")

function FHelper() {
	
	var Mode = value.createList("Mode", ["Normal"], "Normal");
	
    this.getName = function() {
        return "猫染-挖床小助手";
    }
    this.getDescription = function() {
        return "挖床小助手";
    }
    this.getCategory = function() {
        return "Misc"; 
    }
	this.getTag = function() {
        return Mode.get(); 
    }
    this.onEnable = function() {
   
    }
    this.onDisable = function() {
     
    }
    this.onUpdate = function() {
		if(Mode.get() == "Hypixel") {
			if(Fucker.getState() == true && Killaura.getState()) {
				Killaura.setState(false);
				chat.print("[猫染]您打开了Fucker，已为您关闭KillAura");
			}
		}
	}
    this.addValues = function(values) {
        values.add(Mode);
	}
}
var FHelper = new FHelper();
var FHelperClient;

function onLoad() {}

function onEnable() {
    FHelperClient = moduleManager.registerModule(FHelper);
}

function onDisable() {
    moduleManager.unregisterModule(FHelperClient);
}