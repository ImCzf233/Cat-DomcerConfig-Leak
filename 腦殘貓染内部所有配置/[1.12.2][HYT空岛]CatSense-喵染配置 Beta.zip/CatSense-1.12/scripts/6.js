﻿var scriptName = "AntiLagBack";
var scriptAuthor = "AS丶One";
var scriptVersion = 1.0;
var AntiLagBackModule = new AntiLagBackModule();
var Client;
var ticks

function AntiLagBackModule() {
	
	this.getName = function(){
		return "AntiLagBack";
	}
	
	this.getDescription = function() {
		return "Help you fix lagBack";
	}
	this.getCategory = function() {
		return "Fun";
	}
	this.getTag = function() {
		return "cps"
	}
	this.onEnable = function(){
		ticks = 0;
	}
	this.onUpdate = function(){
		if(ticks > 1000){
			mc.thePlayer.isOnLadder()&&mc.gameSettings.keyBindJump.pressed&&(mc.thePlayer.motionY=0.11)
			}
			if(ticks > 2000){
				ticks = 0;
			}else{
				ticks++;
				}
	}
}
function onEnable() {
    Client = moduleManager.registerModule(AntiLagBackModule);
}

function onDisable() {
    moduleManager.unregisterModule(Client);
}