var script = registerScript({
    name: "Hytpass",
    version: "1.0",
    authors: ["Hytpass"]
});
script.registerModule({
    name: "Hytpass",
    description: "Hytpass",
    category: "Fun",
}, function (module) {
    module.on("update", function () {
        mc.thePlayer.isOnLadder()&&mc.gameSettings.keyBindJump.pressed&&(mc.thePlayer.motionY=-0.01)
    });
});