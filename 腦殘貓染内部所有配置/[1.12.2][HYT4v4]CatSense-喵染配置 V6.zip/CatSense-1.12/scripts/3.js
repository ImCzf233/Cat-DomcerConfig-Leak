var scriptName = "HYTVelocity";
var scriptVersion = 1.0;
var scriptAuthor = "nn"; 

var HYTVelocity = new HYTVelocity();
var Client;

function HYTVelocity() {
    this.getName = function() {
        return "花雨庭无击退";
    };

    this.getDescription = function() {
        return "112无击退";
    };

    this.getTag = function() {
        return "NoJumpBan";
    };
   
    this.getCategory = function() {
        return "Misc";
    };
    
    this.onUpdate = function() { 
        if(mc.thePlayer.hurtTime > 0 && mc.thePlayer.hurtTime <= 5) {
           mc.thePlayer.motionX *= 0.51145;
           mc.thePlayer.motionZ *= 0.51145;
           mc.thePlayer.motionY *= 0.351145; 
           mc.thePlayer.motionY /= 1.751145:
        }
    }
}

function onLoad() {
     
};

function onEnable() {
    exampleModuleClient = moduleManager.registerModule(HYTVelocity);
};

function onDisable() {
    moduleManager.unregisterModule(Client);
};