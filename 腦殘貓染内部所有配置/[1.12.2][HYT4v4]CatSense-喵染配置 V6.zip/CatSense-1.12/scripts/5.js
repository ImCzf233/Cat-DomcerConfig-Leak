var scriptName = "BestAntiKB"//魔改倒卖神一律死爹烂妈
var scriptVersion = 1.0
var scriptAuthor = "PacketJuzi"
var JuZiModule = new JuZiModule()
var JuZiModuleClient
var Blink = moduleManager.getModule('Blink')
var ticks = 0
function JuZiModule() {
    this.getName = function() {
        return "NewAntiKb"
    }
    this.getDescription = function() {
        return "ByPassAll"
    }
    this.getCategory = function() {
        return "Fun"
    }
    this.onEnable = function() {
ticks = 0
    }
    this.onDisable = function() { 
ticks = 0
	
    }
    this.onUpdate = function() { 
 if(hurrtime > 0){
Blink.setState(true)
tick == 3
Blink.setState(false)
}
ticks = 0
    }
	this.onPacket = function() { 
    }
}
function onLoad() {}
function onEnable() {
   JuZiModuleClient = moduleManager.registerModule(JuZiModule)
}
function onDisable() {
    moduleManager.unregisterModule(JuZiModuleClient)
}