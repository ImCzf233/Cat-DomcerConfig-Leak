var scriptName = "DomcerAutoBlockHelper";
var scriptVersion = 1.0;
var scriptAuthor = "jia_ran";

var BlockPos = Java.type('net.minecraft.util.BlockPos');
var C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging');
var C08 = Java.type('net.minecraft.network.play.client.C08PacketPlayerBlockPlacement');
var EnumFacing = Java.type('net.minecraft.util.EnumFacing');
var Interactpacket = Java.type('net.minecraft.network.play.client.C02PacketUseEntity');
var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');
var KillAuraClass = Java.type("net.ccbluex.liquidbounce.LiquidBounce").moduleManager.getModule(Java.type("net.ccbluex.liquidbounce.features.module.modules.combat.KillAura").class);
var SAB = new SAB();
var client;

function SAB() {

    var BlockMode = value.createList("DomcerAutoBlockMode", ["Normal", "Packet", "VulCanPacket"], "VulCanPacket");

    this.getName = function() {
        return "Cat-AB";
    };

    this.getTag = function() {
        return "" + BlockMode.get();
    };

    this.getDescription = function() {
        return "Cat-AB";
    };

    this.getCategory = function() {
        return "Combat";
    };

    this.addValues = function(values) {
        values.add(BlockMode);
    }

    this.onAttack = function (event) {
        if (event.getTargetEntity() instanceof EntityPlayer) {
            entity = event.getTargetEntity();
        }
        switch (BlockMode.get()) {
            case "Packet":
                KillAuraClass.blockingStatus = true
                mc.thePlayer.sendQueue.addToSendQueue(new C08(mc.thePlayer.getHeldItem()));
                break;
            case "Normal":
                KillAuraClass.blockingStatus = true
                mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.UP));
                break;
            case "VulCanPacket":
                KillAuraClass.blockingStatus = true
                mc.playerController.interactWithEntitySendPacket(mc.thePlayer, entity)
                break;
        }
    };
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(SAB);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}