﻿var scriptName = "FaBaoJianCe"; 
var scriptVersion = 1.0; 
var scriptAuthor = "xx"; 

var PacketMore = new PacketMore();
var PacketMoreClient;
var colorIndex = 0;

function printMessage(message) {
    var availableColors = ["§a发包过多§b"];
    var color = availableColors[colorIndex];
    colorIndex += 1;
    if (colorIndex >= availableColors.length) {
        colorIndex = 0;
    }
    chat.print(color + message + "§r");
}
function PacketMore() {
	var ticks = 0;
	var packets = 0;
    this.getName = function() {
        return "猫染-发包检测";
    };

    this.getDescription = function() {
        return "检测您的发包";
    };

    this.getCategory = function() {
        return "Fun";
    };
	this.onEnable = function() {
	}

   this.onUpdate = function() {
	   ticks++;
	   if(ticks >= 20) {
		   ticks = 0;
		   packets = 0;
	   }
	   if(packets >=1500) {
		   printMessage("  { 猫染 }当前发包频率 " + packets + "/s");
	   }
   }
    this.onPacket = function() {
		packets++;
		
   }
    this.onDisable = function() {
    }
}
function onLoad() {
};
function onEnable() {
    PacketMoreClient = moduleManager.registerModule(PacketMore);
};
function onDisable() {
    moduleManager.unregisterModule(PacketMoreClient);
};