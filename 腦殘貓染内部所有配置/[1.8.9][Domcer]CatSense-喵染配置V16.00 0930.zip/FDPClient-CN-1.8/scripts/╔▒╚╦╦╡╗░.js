var scriptName = "AutoL";
var scriptVersion = 1.0;
var scriptAuthor = "No People";


var CNM = ["[猫染配置] Kill You"];
var target;
   
var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');


function AutoL() {
    this.getName = function () {
        return "杀人说话";
    };

    this.getDescription = function () {
        return "杀了一个人自动说话";
    };

    this.getCategory = function () {
        return "Misc";
    };
	
	this.getTag = function() {
		return "Killer";
	}
	
    this.onEnable = function () {
		target = null;        
    };


    
    this.onAttack = function (event) {
		if(event.getTargetEntity() instanceof EntityPlayer){
			target = event.getTargetEntity();
		}

    };

    this.onUpdate = function () {		
        if (target != null) {
            if (target.isDead) {
                mc.thePlayer.sendChatMessage("[猫染 Config] 获曲＋⑤伍叁⑧肆酒⑨叁⑥ " );
                target = null;
            }
        }
		
    };

}

var AutoLModule = new AutoL();

var AutoLModuleClient;

function onLoad() {

}

function onEnable() {
    AutoLModuleClient = moduleManager.registerModule(AutoLModule);
}

function onDisable() {
    moduleManager.unregisterModule(AutoLModuleClient);
}