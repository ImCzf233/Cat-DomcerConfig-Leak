按键：
r Killaura 杀戮
v Speed 速度
z Scaffold 自动搭路
y flight 飞行
b phase 穿墙
说明：
NetEase-1.8.9 是配置，放在 C:\MCLDownload\Game\.minecraft 即可



